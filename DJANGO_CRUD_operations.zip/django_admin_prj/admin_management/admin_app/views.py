from django.shortcuts import render,redirect
from django.contrib.auth import authenticate
import logging
import pandas
from .models import Employee
from django.http import JsonResponse
from datetime import datetime


def index(request):
    return render(request,"index.html")


# Create your views here.
logger=logging.getLogger('my_error_django')
def login(request):
    if request.method=='GET':
        return render(request,'login.html')
    elif request.method=='POST':
        username=request.POST['username']
        password=request.POST['password']
        user= authenticate(username=username, password=password)
        if user is not None:
            request.session['username']=username
            return render(request, 'homepage.html', {'message':'You have successfully logged-in'})
        else:
            return render(request,'login.html',{'message':'Username or Password is incorrect'})
        

def upload_csv(request):
    if request.method=='POST' and request.FILES['csv_file']:
        csv_file=request.FILES['csv_file']
        temp_data=pandas.read_csv(csv_file)
        for index, row in temp_data.iterrows():
            date_object= datetime.strptime(str(row['hire_date']), "%d-%m-%Y").date()  #datetime.strptime()changes normal string into date/time obj
            Employee.objects.create(
                            fullname= str(row['fullname']),
                            email= str(row['email']),
                            phone= str(row['phone']),
                            hire_date= date_object)
        return redirect('/homepage/')
    employees= Employee.objects.all()
    return render(request,'homepage.html',{'employees':employees})

def homepage(request):
    employees= Employee.objects.all()
    return render(request, 'homepage.html',{'employees':employees})

def delete(request,employeeId):
    try:
        employee=Employee.objects.get(id=employeeId)
        employee.delete()
        return JsonResponse({"success":True})
    except Employee.DoesNotExist:
        return JsonResponse({'success':False})
    
def update(request,employeeId):
    try:
        employee=Employee.objects.get(id=employeeId)
        return render(request,"update.html",{"employee":employee})
    except Employee.DoesNotExist:
        return JsonResponse({'success':False})

def update_employee(request, employeeId):
    if request.method=='POST':
        try:
            employee= Employee.objects.get(id=employeeId)
            employee.fullname= request.POST.get('fullname')
            employee.email= request.POST.get('email')
            employee.phone= request.POST.get('phone')
            employee.hire_date= request.POST.get('hire_date')
            employee.save()
            return JsonResponse({'success': True})
        except Employee.DoesNotExist:
            pass
    return JsonResponse({'success': False})